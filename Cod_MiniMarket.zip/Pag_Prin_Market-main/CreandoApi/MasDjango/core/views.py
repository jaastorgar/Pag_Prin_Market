from django.shortcuts import render, redirect
from .models import Productos
from .forms import ProductoForm

def home(request):
    productos = Productos.objects.all()
    datos = {
        'productos': productos
    }

    return render(request, 'core/home.html', datos)


def form_producto(request):

    datos = {
        'form': ProductoForm()
    }

    if request.method == 'POST':
        formulario = ProductoForm(request.POST)

        if formulario.is_valid:
            formulario.save()

            datos['mensaje'] = "Guardados correctamente"

    return render(request, 'core/form_producto.html', datos)


def form_mod_producto(request, id):
    producto = Productos.objects.get(idProducto=id)

    datos = {
        'form': ProductoForm(instance=producto)
    }

    return render(request, 'core/form_mod_producto.html', datos)


def form_del_producto(request, id):
    producto = Productos.objects.get(idProducto=id)

    producto.delete()

    return redirect(to="home")

def Pag_principal(request):
    return render(request,'Pag_Princ.html') 

def seccion_carnes (request):
    return render(request,'seccion-carnes.html')

def seccion_licores(request):
    return render(request,'seccion-licores.html')

def seccion_snacks(request):
    return render(request,'seccion-snacks.html')

def seccion_verduras(request):
    return render(request,'seccion-verduras.html')