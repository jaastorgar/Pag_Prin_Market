from django.apps import AppConfig


class RestProductoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rest_producto'
